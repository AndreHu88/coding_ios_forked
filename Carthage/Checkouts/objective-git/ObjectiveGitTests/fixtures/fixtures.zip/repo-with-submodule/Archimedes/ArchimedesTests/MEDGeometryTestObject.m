//
//  MEDGeometryTestObject.m
//  Archimedes
//
//  Created by Justin Spahr-Summers on 2012-10-15.
//  Copyright (c) 2012 GitHub. All rights reserved.
//

#import "MEDGeometryTestObject.h"

@implementation MEDGeometryTestObject
@end
