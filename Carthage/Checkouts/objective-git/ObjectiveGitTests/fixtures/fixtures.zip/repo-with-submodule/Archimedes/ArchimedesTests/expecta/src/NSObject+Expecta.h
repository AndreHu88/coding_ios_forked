#import <Foundation/Foundation.h>

@interface NSObject (Expecta)
- (void)failWithException:(NSException *)exception;
@end
