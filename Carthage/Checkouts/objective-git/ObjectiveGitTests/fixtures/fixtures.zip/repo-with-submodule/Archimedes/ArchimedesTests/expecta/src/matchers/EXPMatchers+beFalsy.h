#import "Expecta.h"

EXPMatcherInterface(beFalsy, (void));
