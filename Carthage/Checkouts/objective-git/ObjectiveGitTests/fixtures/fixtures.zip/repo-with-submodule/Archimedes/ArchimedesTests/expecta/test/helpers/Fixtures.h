#import <Foundation/Foundation.h>

@interface Foo : NSObject; @end;
@interface Bar : Foo; @end;
@interface Baz : NSObject; @end;
