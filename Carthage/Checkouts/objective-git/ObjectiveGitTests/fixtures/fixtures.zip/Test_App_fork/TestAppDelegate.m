//
//  TestAppDelegate.m
//  Test
//
<<<<<<< HEAD
//  JoeCode™
//
=======
>>>>>>> 7bdd5e13ade0be38dc2c62af5e68381d8abf6c53

#import "TestAppDelegate.h"
#import "TestAppWindowController.h"

@implementation TestAppDelegate

@synthesize windowController;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {

	self.windowController = [[TestAppWindowController alloc] initWithWindowNibName:@"TestAppWindow"];
	[self.windowController showWindow:self];
}

@end
