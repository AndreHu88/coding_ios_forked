#import <Cocoa/Cocoa.h>

int foobar(int argc, char *argv[])
{
    return NSApplicationFoo(argc,  (const bar **) argv);
}
123456789
123456789
123456789
123456789
12
